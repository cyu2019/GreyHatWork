#pragma once

#define	FL_ONGROUND	(1<<0)
