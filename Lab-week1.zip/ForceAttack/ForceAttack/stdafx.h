#pragma once

#include "targetver.h"

// for _getch()
#include <conio.h>